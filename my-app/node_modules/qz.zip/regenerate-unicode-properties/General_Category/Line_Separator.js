const set = require('regenerate')(0x2028);

exports.characters = set;
