const set = require('regenerate')();
set.addRange(0x16E40, 0x16E9A);
exports.characters = set;
