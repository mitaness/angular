const set = require('regenerate')(0x171F);
set.addRange(0x1700, 0x1715);
exports.characters = set;
